# l4d2-map-selector
Left 4 Dead 2 Map Selector

## 1. Click the link below to download the latest version of the source code:

> GitHub Release: https://github.com/syenlxyz/l4d2-map-selector/releases

## 2. Double-click `run.bat` to execute the program.

> Do not close the command prompt when the program is still in use (closing the command prompt will close the program).

Preview:

<img src="run.png">

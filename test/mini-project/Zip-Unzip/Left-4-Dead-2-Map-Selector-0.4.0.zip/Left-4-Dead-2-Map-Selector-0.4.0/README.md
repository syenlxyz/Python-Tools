# Left 4 Dead 2 Map Selector

### 1. Click the link below to download the latest version of the source code:

> GitHub Releases: https://github.com/syenlxyz/Left-4-Dead-2-Map-Selector/releases

### 2. Double-click `run.bat` to execute the program.

> Do not close the command prompt when the program is still in use (closing the command prompt will close the program).

Preview:

<img src="run.png">
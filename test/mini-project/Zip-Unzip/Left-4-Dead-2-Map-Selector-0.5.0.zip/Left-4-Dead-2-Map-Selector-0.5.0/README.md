# Left 4 Dead 2 Map Selector

### 1. Click the link below to download the latest version of the source code:

GitHub Releases: https://github.com/syenlxyz/Left-4-Dead-2-Map-Selector/releases

### 2. Double-click `run.vbs` to run the program.

Preview:

<img src="run.png">